//
//  LiveView.swift
//  
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//

import PlaygroundSupport
import BrickBreakerLiveView

let liveViewController = BrickBreakerViewController()


PlaygroundPage.current.liveView = liveViewController
